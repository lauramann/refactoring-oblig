# Refactoring

Follows the video store refactoring example from Chapter 1 of
[_Refactoring_](http://amzn.to/2j6IvB5) by Martin Fowler.

## Branches

* `master` includes the video store code from the book
* `tests` includes tests for the code in `master`
* `refactoring` walks step-by-step through the refactorings from Chapter 1
